# Termux-Styling-Shell-Script
Unofficial Termux Styling [ Bash ]

Usage:
```
$ ./termux-styling.sh --help
```

Contact: [z@bl33dz.me] or [bagaz@protonmail.ch]
