## PYCOMPILET
```
pkg install update
pkg install upgrade
pkg install nano
pkg install random
pkg install git
pkg install time
git clone https://github.com/Aldi098/PYCOMPILET
cd PYCOMPILET
ls
pip install -r requirements.txt
python2 Pycompilet_enc.py
```
## FUNGSI
```
> Encypt Base16
> Encypt Base32
> Encypt Base64
> Encypt Hex
> Encypt Marshal
> Encypt py > pyc
> Encypt Marshal Zlib Base64
> Encypt Zlib
> √ 100% WORK
```
## THANK YOU
```
> Allah SWT
> Bapak
> Ibu
> Kaka
> Teman²
```
```
Link Key : http://Wa.me/6285295004078?text=!KEY
```
