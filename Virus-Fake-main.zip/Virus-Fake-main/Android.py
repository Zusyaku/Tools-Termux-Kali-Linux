import os,time,sys
from datetime import datetime

def ketik(teks):
 for i in teks + "\n":
  sys.stdout.write(i)
  sys.stdout.flush()
  time.sleep(0.01)
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod






#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod







#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod








#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod
#kqng ricod

#kqng ricod













#kqng ricod















#kqng ricod












#kqng ricod









#kqng ricod










#kqng ricod









#kqng ricod









#kqng ricod









#kqng ricod








#kqng ricod







#kqng ricod







#kqng ricod
saat_ini = datetime.now()
tgl = saat_ini.strftime('%d')
bln = saat_ini.strftime('%m')
thn = saat_ini.strftime('%Y')
waktu_new = (tgl+"-"+bln+"-"+thn)
xnxx="\033[85m"
q="\033[00m"
h2="\033[40m"
b2="\033[44m"
c2="\033[46m"
i2="\033[42m"
u2="\033[45m"
m2="\033[41m"
p2="\033[47m"
k2="\033[43m"
b='\033[1;34m'
i='\033[1;32m'
c='\033[1;36m'
m='\033[1;31m'
u='\033[1;35m'
k='\033[1;33m'
p='\033[1;37m'
h='\033[1;90m'
k3="\033[43m\033[1;37m"
b3="\033[44m\033[1;37m"
m3="\033[41m\033[1;37m"

os.system("clear")
ketik(m +"       .---.        .----------- ")
ketik(m +"      /     \  __  /    ------        "+ k +" ["+ m +" VIRUS ANDROID"+ k +" ]")
ketik(m +"     / /     \(  )/    ----- ")
ketik(m +"    //////   ' \/ `   ---    "+ p +"    ➣"+ k +" Creator"+ m +" :"+ h +" ALDI BACHTIAR RIFAI")
ketik(m +"   //// / // :    : ---      "+ p +"    ➣"+ k +" Youtube"+ m +" :"+ h +" MR.1557 / B0C4H")
ketik(p +"  // /   /  /`    '--        "+ p +"    ➣"+ k +" Github"+ m +"  :"+ h +" https://github.com/Aldi098")
ketik(p +" //          //..\\ ")
ketik(p +"        ====UU====UU====       "+ k +"          ["+ m +" VERSI 0.2"+ k +" ]")
ketik(p +"            '//||\\` ")
ketik(p +"              ''``  ")
ketik("")
try:
    isi = input(p +" ➣"+ k +" Masukan Nomer "+ m +": "+ i)
    mulai = input(p +" ➣"+ k +" Lanjut?"+ i +" y"+ k  +"/"+ m +"t "+ m +": "+ i)
    print("")
    print("")
except (KeyboardInterrupt,EOFError):
        ketik (m +' !'+ p +' BAY KONTOL!!')
        sys.exit()
if mulai == "y":
   print(m +" !"+ k +" Virus"+ p +" Sedang Di Siapkan")
   time.sleep(2)
   print("")
   ulang = 1000000000000000000000000000000000000000000000000
   for i in range(ulang):
      time.sleep(0.01)
      print ("\033[1;32m ✓{} Berhasil Mengirim{} Virus{} Ke Nomor >{} {}".format(p, m, p, k, isi))
elif mulai == "t":
    print (m +" !"+ p +" program berhenti")
else:
    print (m +" !"+ p +" tidak tersedia")
