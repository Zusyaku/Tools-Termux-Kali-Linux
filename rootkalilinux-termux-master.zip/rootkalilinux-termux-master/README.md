### rootkalilinux-termux

# Find me on 

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈

### screenshot

![ ](https://github.com/shubhamggosai/rootkalilinux-termux/blob/master/Screenshot/Screenshot_20200916_164237.jpg)
![ ](https://github.com/shubhamggosai/rootkalilinux-termux/blob/master/Screenshot/Screenshot_20200916_165257.jpg)
![ ](https://github.com/shubhamggosai/rootkalilinux-termux/blob/master/Screenshot/Screenshot_20200916_170706.jpg)

### Also install sudo for termux

### https://github.com/shubhamggosai/sudo_for_termux


### installation
 pkg update

 pkg upgrade

 pkg install curl proot tar -y

 git clone https://GitHub.com/ShuBhamg0sain/rootkalilinux-termux.git
 
 cd rootkalilinux-termux
 
 ls

 bash Kali.sh
 
### use single command

 pkg update -y && pkg install curl proot tar -y && curl https://raw.githubusercontent.com/AndronixApp/AndronixOrigin/master/Installer/Kali/kali.sh | bash
