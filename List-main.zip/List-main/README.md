# List
```
- pkg install nano

- pkg install git

- pkg install bash

- pkg install figlet

- git clone https://github.com/Aldi098/List

- cd List

- bash virus-teks.sh

```
