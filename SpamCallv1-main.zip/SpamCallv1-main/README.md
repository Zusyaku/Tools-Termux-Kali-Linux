# SpamCallv1

1.pkg update && pkg upgrade

2.pkg install python

3.pkg install git

4.git clone https://github.com/MrSadClown/SpamCallv1

5.cd SpamCallv1

6.ls

7.python Spam.py
