## Checkboxes

- [ ] Updated fsociety
- [ ] Issue does not already exist
- [ ] fsociety issue, not a tool issue

## Expected Result

```bash

```

## Actual Result

```bash

```

