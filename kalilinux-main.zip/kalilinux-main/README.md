# kalilinux

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈

Kalilinux in android phone using termux

![ ](https://raw.githubusercontent.com/ShuBhamg0sain/kalilinux/main/images%20(1).jpeg)

# Requirements
*  vncserver app from Google Play Store
* Termux app from Google Play Store
# installation process

## termux-setup-storage

## pkg install wget

## wget -O install-nethunter-termux https://offs.ec/2MceZWr

## chmod +x install-nethunter-termux

## ./install-nethunter-termux

# Now you see this 

![ ](https://raw.githubusercontent.com/ShuBhamg0sain/kalilinux/main/images.png)

# Type 
## nethunter kex passwd
this for set password

# type 
 ## nethunter kex &    
 start vncserver in termux
# then open vncserver app click + icon and add address as localhost:1 and name as kali and create it and ok

![ ](https://raw.githubusercontent.com/ShuBhamg0sain/kalilinux/main/Screenshot_20190805-221720.png)
![ ](https://raw.githubusercontent.com/ShuBhamg0sain/kalilinux/main/images.jpeg)
# For Stop the kali go to termux and type 
## nethunter kex stop
