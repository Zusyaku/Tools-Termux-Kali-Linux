TekDefense-Automater Version: 0.21
====================

http://www.tekdefense.com/automater/
http://www.tekdefense.com/news/2013/12/4/finally-the-new-automater-release-is-out.html


Automater is a tool that I originally created to automate the OSINT analysis of IP addresses. It quickly grew and became a tool to do analysis of IP Addresses, URLs, and Hashes. Unfortunately though, this was my first python project and I made a lot of mistakes, and as the project grew it bacame VERY hard for me to maintain. 

Luckily, a mentor and friend of mine (@jameshub3r) offered his time and expertise to do an enitre re-write of the code that would focus on a modular extensible framework. The new code hits the mark as far as that is concerned. The real power of Automater is how easy it is to modify what sources are checked and what data is taken from them without having to modify the python code. To modify sources simply open up the sites.xml file and modify away. I'll do another post later that goes into more detail there.

To view a bit more about installation and usage head over to the new Automater page (http://www.tekdefense.com/automater/).

You can download the code directly on Github. Remember Automater is not a single file anymore, you need to download all of the files in the Automater repo to the same directory.
