# ONIOFF Reports

- Author: Nikolaos Kamarinakis ([nikolaskama.me](https://nikolaskama.me/))

DO NOT DELETE THIS DIRECTORY.
INSPECTIONS WITHOUT SPECIFIED OUTPUT FILENAMES ARE SAVED HERE.
