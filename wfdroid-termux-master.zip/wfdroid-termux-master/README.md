# wfdroid V 1.0 on TermuX.

Force the Website with Android

Install TermuX before! in your Android:

https://play.google.com/store/apps/details?id=com.termux

How to Install wfdroid ?
1. Open your TermuX
2. wget https://raw.githubusercontent.com/bytezcrew/wfdroid-termux/master/installer
3. ./installer

by Schopath ( BytezCrew )

Greet:

Ccocot ~ l0c4lh34rtz ~ Jingklong

BAHARI TROUBLE MAKER (team) - INDOXPLOIT (team) - BERDENDANGC0DE (team)
