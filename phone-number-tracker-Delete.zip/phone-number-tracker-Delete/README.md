
const-string v25, "🥀❥︎ᴡɪᴅᴇ ᴠɪᴇᴡ"

    new-instance v26, Lvignesh/mods/espmenu/FloatingModMenuService$100000117;

    move-object/from16 v31, v26

    move-object/from16 v26, v31

    move-object/from16 v27, v31

    move-object/from16 v28, v2

    invoke-direct/range {v27 .. v28}, Lvignesh/mods/espmenu/FloatingModMenuService$100000117;-><init>(Lvignesh/mods/espmenu/FloatingModMenuService;)V

    invoke-direct/range {v24 .. v26}, Lvignesh/mods/espmenu/FloatingModMenuService;->AddToggle7(Ljava/lang/String;Landroid/widget/CompoundButton$OnCheckedChangeListener;)V


# phone-number-tracker

# Note
# Find me for username and password
# My Instagram acc

# Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈

# YouTube video
[![video](https://img.shields.io/badge/YOUTUBE-VIDEO-red?style=for-the-badge&logo=instagram)](https://youtu.be/8t-2h-1y14U)
# screenshot
![ ](https://raw.githubusercontent.com/ShuBhamg0sain/phone-number-tracker/Delete/Screenshot_20211009_191804.jpg)
# Installation
apt update -y

 apt upgrade -y

 apt install git -y

 apt install python -y

 apt install python2 -y

 pip2 install requests

 pip2 install mechanize

git clone https://github.com/ShuBhamg0sain/phone-number-tracker

cd phone-number-tracker
 
# ussage 
python2 tracker.py number
