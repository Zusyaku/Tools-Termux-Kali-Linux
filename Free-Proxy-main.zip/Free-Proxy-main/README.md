# Free-Proxy

## install
```python
$ pkg install python
$ pkg install python2
$ pkg install nano
$ pkg install git
$ git clone https://github.com/Aldi098/Free-Proxy
$ cd Free-Proxy
$ pip2 install -r requirements.txt
$ python2 free-proxy.py

```

## fungsi
- [x] Mengambil proxy
- [x] Mengambil domain
- [x] menggunakan url

> jika script nya ngga berfungsi berarti apinya koid 😂😂😂

## Thanks for you
```php
 Polygon
 Panglima Jateng
 Dan semua team panglima Jateng
```
## Support Me On
<b>• [Youtube](https://youtube.com/channel/UC7ygjAbDjuiN76PqOlJm40A)</b>
</br>
## WhatsApp
<b>• [WhatsApp](https://api.whatsapp.com/send?phone=+62852-9500-4078&text=Assalamualaikum)</b>
<br>
