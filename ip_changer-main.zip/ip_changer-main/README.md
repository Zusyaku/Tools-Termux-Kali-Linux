# ip_changer 
Change your Ip address many times
 Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈

# Run as root 
# installation
apt update

apt upgrade

apt install tor

git clone https://github.com/ShuBhamg0sain/ip_changer

cd ip_changer

chmod +x fast.sh

./fast.sh

https://www.torproject.org/download/download#warning
