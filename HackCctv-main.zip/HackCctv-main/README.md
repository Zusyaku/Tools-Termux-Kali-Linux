# HackCctv

1.pkg update && pkg upgrade

2.pkg install python

3.pkg install figlet

4.pkg install git

5.git clone https://github.com/MrSadClown/HackCctv

6.cd HackCctv

7.ls

8.python cctv.py
