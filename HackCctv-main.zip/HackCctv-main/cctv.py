#!/ban/python
#Gua Cape Ngoding Lu Tinggal Recode Author emang gtu sopan?
#Seengganya lu Izin dah ke gua

# module
import os,sys,time,requests
from time import sleep

#warna	
red   = '\x1b[31m' # Merah
green = '\x1b[32m' # Hijau
yellow = '\x1b[33m' # Kuning
blue  = '\x1b[34m' # Biru
magenta = '\x1b[35m' # Ungu
cyan  = '\x1b[36m' # Biru Muda
white = '\x1b[37m' # Putih
reset = '\x1b[39m' # Reset Warna ( Kembali Ke Warna Awal )
brblack = '\x1b[90m' # Hitam Terang
R = '\x1b[91m' # Merah Terang
brgreen = '\x1b[92m' # Hijau Terang
k = '\x1b[93m' # Kuning Terang
brblue = '\x1b[94m' # Biru Terang
brmgnt = '\x1b[95m' # Ungu Terang
brcyan = '\x1b[96m' # Biru Muda Terang
G = '\x1b[97m' # Putih Terang
pilih = input("Siapa Nama Kaka :")


#Tampilan
os.system("xdg-open https://youtube.com/channel/UCGRRm4GgoaGwWM2NQxr2nIA")
print('\x1b[91m')
os.system("clear")
os.system("figlet hay "  +  pilih)
print('\x1b[31m┈╭━━━━━━━━━━━╮┈                                   ')
print('\x1b[31m┈┃╭━━━╮┊╭━━━╮┃┈                                   ')
print('\x1b[31m╭┫┃┈▇┈┃┊┃┈▇┈┃┣╮           Hack CCTV               ')
print('\x1b[31m┃┃╰━━━╯┊╰━━━╯┃┃      Author : Mr.SadClown         ')
print('\x1b[97m╰┫╭━╮╰━━━╯╭━╮┣╯      My Team:WHITE CYBER UNION    ')
print('\x1b[97m┈┃┃┣┳┳┳┳┳┳┳┫┃┃┈    My Github:github.com/MrSadClown')
print('\x1b[97m┈┃┃╰┻┻┻┻┻┻┻╯┃┃┈                                   ')
print('\x1b[97m┈╰━━━━━━━━━━━╯┈                                   ')
print('      ')
print('----------------------------------------------------------')
print('Pilih Salah Satu Ya Ngab')
print('    ')
print('\x1b[35m['+'\x1b[94m1'+'\x1b[35m]'+'\x1b[33mHackCctv1')
print('\x1b[35m['+'\x1b[94m2'+'\x1b[35m]'+'\x1b[33mHackCctv2')
print('\x1b[35m['+'\x1b[94m3'+'\x1b[35m]'+'\x1b[33mHackCctv3')
print('\x1b[35m['+'\x1b[94m4'+'\x1b[35m]'+'\x1b[33mHackCctv4')
print('   ')
print('==========================================================')
pilih = input('Pilih No Berapa :')
print('    ')
os.system("clear")
if pilih =="1":
   sleep(2)
   print('Bentar Yah Ngab Proses:v')
   sleep(2)
   os.system("clear")
   os.system("figlet hay Lagi")
   print('\x1b[31m┈╭━━━━━━━━━━━╮┈                                   ')
   print('\x1b[31m┈┃╭━━━╮┊╭━━━╮┃┈                                   ')
   print('\x1b[31m╭┫┃┈▇┈┃┊┃┈▇┈┃┣╮           Hack CCTV               ')
   print('\x1b[31m┃┃╰━━━╯┊╰━━━╯┃┃      Author : Mr.SadClown         ')
   print('\x1b[97m╰┫╭━╮╰━━━╯╭━╮┣╯      My Team:WHITE CYBER UNION    ')
   print('\x1b[97m┈┃┃┣┳┳┳┳┳┳┳┫┃┃┈    My Github:github.com/MrSadClown')
   print('\x1b[97m┈┃┃╰┻┻┻┻┻┻┻╯┃┃┈                                   ')
   print('\x1b[97m┈╰━━━━━━━━━━━╯┈                                   ')
   print('      ')
   print('----------------------------------------------------------')
   print('\x1b[33mNote:Copy Lalu Paste Di Chrom')
   print('    ')
   print('\x1b[31m   ( '+'\x1b[97m119.2.50.116:89'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m119.2.50.116:91'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m119.2.50.116:84'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m84.33.80.155:84'+'\x1b[31m )')
   print('    ')
   print('\x1b[95mOke Makasih Udah pake tools kami')
if pilih =="2":
   sleep(2)
   print("Bentar Tod Sabar")
   sleep(2)
   os.system("clear")
   os.system("figlet hay Lagi Tod")
   print('\x1b[31m┈╭━━━━━━━━━━━╮┈                                   ')
   print('\x1b[31m┈┃╭━━━╮┊╭━━━╮┃┈                                   ')
   print('\x1b[31m╭┫┃┈▇┈┃┊┃┈▇┈┃┣╮           Hack CCTV               ')
   print('\x1b[31m┃┃╰━━━╯┊╰━━━╯┃┃      Author : Mr.SadClown         ')
   print('\x1b[97m╰┫╭━╮╰━━━╯╭━╮┣╯      My Team:WHITE CYBER UNION    ')
   print('\x1b[97m┈┃┃┣┳┳┳┳┳┳┳┫┃┃┈    My Github:github.com/MrSadClown')
   print('\x1b[97m┈┃┃╰┻┻┻┻┻┻┻╯┃┃┈                                   ')
   print('\x1b[97m┈╰━━━━━━━━━━━╯┈                                   ')
   print('      ')
   print('----------------------------------------------------------')
   print('\x1b[33mNote:Copy Lalu Paste Di Chrom')
   print('    ')
   print('\x1b[31m   ( '+'\x1b[97m14.54.243.66:8083'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m14.54.243.66:8082'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m58.184.253.10:80'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m84.33.80.155:85'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m203.250.69.180:80'+'\x1b[31m )')
   print('    ')
   print('\x1b[95mOke Makasih Udah pake tools kami')
if pilih =="3":
   sleep(2)
   print("Bentar Tod Sabar")
   sleep(2)
   os.system("clear")
   os.system("figlet Yee Lu Lagi")
   print('\x1b[31m┈╭━━━━━━━━━━━╮┈                                   ')
   print('\x1b[31m┈┃╭━━━╮┊╭━━━╮┃┈                                   ')
   print('\x1b[31m╭┫┃┈▇┈┃┊┃┈▇┈┃┣╮           Hack CCTV               ')
   print('\x1b[31m┃┃╰━━━╯┊╰━━━╯┃┃      Author : Mr.SadClown         ')
   print('\x1b[97m╰┫╭━╮╰━━━╯╭━╮┣╯      My Team:WHITE CYBER UNION    ')
   print('\x1b[97m┈┃┃┣┳┳┳┳┳┳┳┫┃┃┈    My Github:github.com/MrSadClown')
   print('\x1b[97m┈┃┃╰┻┻┻┻┻┻┻╯┃┃┈                                   ')
   print('\x1b[97m┈╰━━━━━━━━━━━╯┈                                   ')
   print('      ')
   print('----------------------------------------------------------')
   print('\x1b[33mNote:Copy Lalu Paste Di Chrom')
   print('    ')
   print('\x1b[31m   ( '+'\x1b[97m84.33.80.155:85'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m210.128.188.40:80'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m202.237.132.50:80'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m220.109.231.253:80'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m211.1.102.182:80'+'\x1b[31m )')
   print('    ')
   print('\x1b[95mOke Makasih Udah pake tools kami')
if pilih=="4":
   sleep(2)
   print("Bentar Tod Sabar")
   sleep(2)
   os.system("clear")
   os.system("figlet Aelah Lu Lagi")
   print('\x1b[31m┈╭━━━━━━━━━━━╮┈                                   ')
   print('\x1b[31m┈┃╭━━━╮┊╭━━━╮┃┈                                   ')
   print('\x1b[31m╭┫┃┈▇┈┃┊┃┈▇┈┃┣╮           Hack CCTV               ')
   print('\x1b[31m┃┃╰━━━╯┊╰━━━╯┃┃      Author : Mr.SadClown         ')
   print('\x1b[97m╰┫╭━╮╰━━━╯╭━╮┣╯      My Team:WHITE CYBER UNION    ')
   print('\x1b[97m┈┃┃┣┳┳┳┳┳┳┳┫┃┃┈    My Github:github.com/MrSadClown')
   print('\x1b[97m┈┃┃╰┻┻┻┻┻┻┻╯┃┃┈                                   ')
   print('\x1b[97m┈╰━━━━━━━━━━━╯┈                                   ')
   print('      ')
   print('----------------------------------------------------------')
   print('\x1b[33mNote:Copy Lalu Paste Di Chrom')
   print('    ')
   print('\x1b[31m   ( '+'\x1b[97m84.154.52.86:8000'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m185.140.255.102:8090'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m84.154.52.86:8000'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m185.72.41.126:90'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m84.151.230.164:83'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m202.52.50.183:8001'+'\x1b[31m )')
   print('\x1b[31m   ( '+'\x1b[97m82.127.180.180:88 '+'\x1b[31m )')
   print('    ')
   print('\x1b[95mOke Makasih Udah pake tools kami')
