# SEPESIAL-50SUBS

![Aldi098](https://github.com/Aldi098/SEPESIAL-50SUBS/blob/main/Screenshot_20210922_143011.jpg)

# cara install nya

```pkg install nano```

```pkg install git```

```pkg install python2```

```git clone https://github.com/Aldi098/SEPESIAL-50SUBS```

```cd SEPESIAL-50SUBS```

```python2 main.py```

# Thanks you
```
- Allah SWT
- bapak
- ibu
- Kaka
- teman² yg udah subscribe
```
