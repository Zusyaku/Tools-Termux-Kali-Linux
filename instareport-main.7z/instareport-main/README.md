# instareport
Report instagram user account

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈

─▄█████████████████▄─
▄█▀█░█░░░░░░░░░░░░▀█▄
 █░█░█░░░░░░░█████░░█
 █░█░█░░░░░░░█████░░█
 █░█░█░░░░░░░░░░░░░░█
 █░░░░░░▄▄▄███▄▄▄░░░█
 █████████▀▀░▀▀██████
 █░░░░░█░░▄███▄░░█░░█
 █░░░░░█░██▀░▀██░█░░█
 █░░░░░█░██░░░██░█░░█
 █░░░░░█░██▄░▄██░█░░█
 █░░░░░█▄░▀███▀░▄█░░█
 █░░░░░▀██▄▄░▄▄██▀░░█
 █░░░░░░░▀▀███▀▀░░░░█
█▄░instareport░░░░░░░▄█
█▄░by@shubham_g0sain░▄█
▀█▄░BLACK-KILLER░░░░░▄█▀
 ─▀███████████████▀─

## Installation [Linux](https://wikipedia.org/wiki/Linux) [![alt tag](http://icons.iconarchive.com/icons/dakirby309/simply-styled/32/OS-Linux-icon.png)](https://fr.wikipedia.org/wiki/Linux)
```bash
git clone https://github.com/ShuBhamg0sain/instareport.git
cd instareport
pip install requests
python2 linux.py
```
#set username and password


instareport
## Installation [Android](https://wikipedia.org/wiki/Android) [![alt tag](https://cdn1.iconfinder.com/data/icons/logotypes/32/android-32.png)](https://fr.wikipedia.org/wiki/Android)

Download [Termux](https://play.google.com/store/apps/details?id=com.termux)

```bash
pkg install git
pkg install python
git clone https://github.com/ShuBhamg0sain/instareport.git
cd instareport
python3 -m pip install requests
python2 termux.py
```
#set your username and password

