## Webdev
```
OPEN SOURCE
```
## install
```
pkg install wget
pkg install toilet
wget install lolcat
Selanjutnya Luh yg nerusin males ngetik^_^
```


## Jika ada kesalahan sama minta maaf karena saya juga belajar 







``` Makasih yg udah subscribe channel aku Yo ```
