WifiBruteCrack
==============

Python script to attempt to brute force all wifi networks in range of a device, and return a possible set of networks to connect to and the password,
