#include <io.h>
 
#define inline __inline 

#include "win32_getopt.h"
 
#define strcasecmp(s1, s2) _stricmp(s1, s2)