# rootubantu-termux

# Find me on 

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈


![ ](https://github.com/shubhamggosai/rootubantu-termux/blob/master/IMG_20200916_180231.jpg)

### Also install sudo for termux

### https://github.com/ShuBhamg0sain/sudo_for_termux


### installation
 pkg update

 pkg upgrade

 pkg install curl proot tar -y

 git clone https://GitHub.com/ShuBhamg0sain/rootubantu-termux.git
 
 cd rootubantu-termux
 
 ls

 Select version

 bash ubantu1.0.sh 

      Or 

 bash ubantu2.0.sh
 
### use single command
 # for ubantu version 1.0

 pkg update -y && pkg install curl proot tar -y && curl https://raw.githubusercontent.com/AndronixApp/AndronixOrigin/master/Installer/Ubuntu/ubuntu.sh | bash
 
 # for ubantu version 2.0
 
 pkg update -y && pkg install curl proot tar -y && curl https://raw.githubusercontent.com/AndronixApp/AndronixOrigin/master/Installer/Ubuntu20/ubuntu20.sh | bash



