> **NOTE:** This project is no longer being maintained. Thankfully, @trimstray revamped into a much more badass version and you can check it out at [his GitHub repository](https://github.com/trimstray/multitor).

Multi-TOR
=========

Tools for handling multiple TOR connections

* multitor.sh - opens multiple TOR instances
* tor_newid.sh - requests new identity (IP address) to multiple TOR instances

Changelog
-------------
* 2013-09-09    Added tor_newid.sh
