# Boom Chat Messenger Fb
-----------------------


# BUKA TERMUX KETIK

```
pkg install update

pkg install upgrade

pkg install git

pkg install python2

pip2 install --upgrade pip

git clone https://github.com/errorBrain/spamchat.git

cd Spamchat

pip2 install -r requirements.txt

python2 messenger.py
```

# DONE
Author : Senitopeng
