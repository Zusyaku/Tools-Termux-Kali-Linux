# Tutorial-YT

Tutorial membuat SC encypt dengan modul marshal

Bahan²

```pkg install update```

```pkg install nano```

```pkg install python```
