# login_finder
Admin login finder by N1ght.Hax0r
# Dependency
php , php-curl
# Usage
php finder.php
