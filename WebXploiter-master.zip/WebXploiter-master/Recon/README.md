Other Module
=============

This module is written so that we can probably guess if any attacks are possible. If so, the tools shows the output for the same with any online tools that you can use to confirm if the attack really exist.
