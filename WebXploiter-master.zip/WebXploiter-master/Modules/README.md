# Modules

For easy maintainance, the attack vectors are classified in modules on the basis of [OWASP Top 10](https://www.owasp.org/index.php/Top_10_2013-Top_10) attack vectors.

Contribute:
-----------

If you have any feature requests or came across any bugs, do add a new [issue](https://github.com/team-bi0s/WebXploiter/issues) or give a pull request ;)
