FUzZ Database:
--------------

This is a small collection of Fuzz database that I have collected from various
sources in the Internet.

Contribute:
-----------
If you are very good at fuzzing or if you would like to mention a few tips for the development of the project, please do add a new [issue](https://github.com/team-bi0s/WebXploiter/issues) or give a pull request ;)
