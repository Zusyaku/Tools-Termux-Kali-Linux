# Installation

Supported Distros:
------------------
Debian - Ubuntu derivatives (with apt-get support)

Requirements:
-------------
Python 2.7

Installation:
-------------
Just run `python install.py` from install directory. Rest is taken care of :)

Documentation:
--------------
http://webxploiter.readthedocs.org/
