# Evil-I
Termux-Banner

gitgit clone  https://github.com/rixon-cochi/Evil-eye

Cd Evil-eye

Chmod +x *

bash requirement.sh

bash Evil-l.sh

