# MY-TOOLS
## Installasi
```php
$ pkg update && pkg upgrade
$ pkg install git
$ pkg install python
$ git clone https://github.com/Aldi098/MY-TOOLS
$ cd MY-TOOLS
$ pip install -r requirements.txt
$ python TOOLS.py
```
## Function
- [x] MY IP
- [x] Informasi nomor hp
- [x] Information ip
- [x] ATTACK WEB
