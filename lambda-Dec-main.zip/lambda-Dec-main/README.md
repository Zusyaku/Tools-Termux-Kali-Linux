# lambda-Dec


## install
```python
$ pkg install python
$ pkg install python3
$ pkg install nano
$ pkg install git
$ git clone https://github.com/Aldi098/lambda-Dec
$ cd lambda-Dec
$ pip install -r requirements.txt
$ python run.py

```

## fungsi
- [x] lambda marshal
- [x] lambda Zlib
- [x] lambda base64
- [x] lambda Base32
- [x] lambda base16
- [x] DLL

> Get Token [click here](https://sfile.mobi/34w5pODdgI3)
## Thanks for you
```php
 Polygon
 Panglima Jateng
 Dan semua team panglima Jateng
```
## Support Me On
<b>• [Youtube](https://youtube.com/channel/UC7ygjAbDjuiN76PqOlJm40A)</b>
</br>
## WhatsApp
<b>• [WhatsApp](https://api.whatsapp.com/send?phone=+62852-9500-4078&text=Assalamualaikum)</b>
<br>
