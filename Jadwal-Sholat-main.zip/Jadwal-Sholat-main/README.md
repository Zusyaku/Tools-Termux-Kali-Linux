# Jadwal-Sholat

## install
```python
$ pkg install python
$ pkg install python3
$ pkg install nano
$ pkg install git
$ git clone https://github.com/Aldi098/Jadwal-Sholat
$ cd Jadwal-Sholat
$ pip2 install -r requirements.txt
$ python2 jadwal-sholat.py

```

## fungsi
- [x] Jadwal sholat Fajar
- [x] Jadwal sholat Shurooq
- [x] Jadwal sholat Dhuhur
- [x] Jadwal sholat Asar
- [x] Jadwal sholat Maghrib
- [x] Jadwal sholat Isya'

> jika script nya ngga berfungsi berarti apinya koid 😂😂😂

## Thanks for you
```php
 Polygon
 Panglima Jateng
 Dan semua team panglima Jateng
```
## Support Me On
<b>• [Youtube](https://youtube.com/channel/UC7ygjAbDjuiN76PqOlJm40A)</b>
</br>
## WhatsApp
<b>• [WhatsApp](https://api.whatsapp.com/send?phone=+62852-9500-4078&text=Assalamualaikum)</b>
<br>
