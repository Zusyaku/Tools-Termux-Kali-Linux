# GoogleSearch-CLI
Search anything on Google without captcha

# How to use
1. Make sure PHP Lib is already installed on your pc<br>
2. Then open it on your terminal with this command `php GoogleSearch.php`<br>

# Review
![LINE](https://image.prntscr.com/image/-B2GJzkJQGCqF8xOWOJ8OA.png)

# Special Thanks
Special Thanks To Teguh Aprianto (https://www.facebook.com/Teguhmicro)

# More Information
Alternative cx / cse code (If the Default one isn't work), But this one bellow is only takes 10K query per-day<br>
`cx=015050873726381757316:8jbkip1m_6w`
