# GHOSTSPLOIT-  

# follow me👇
Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈

# screenshot
![ ](https://raw.githubusercontent.com/ShuBhamg0sain/GHOSTSPLOIT/main/SS/IMG_20210525_100554.jpg)
![ ](https://raw.githubusercontent.com/ShuBhamg0sain/GHOSTSPLOIT/main/SS/IMG_20210525_100503.jpg)

## Installation [Linux](https://wikipedia.org/wiki/Linux) [![alt tag](http://icons.iconarchive.com/icons/dakirby309/simply-styled/32/OS-Linux-icon.png)](https://fr.wikipedia.org/wiki/Linux)
```bash
sudo apt update
sudo apt upgrade
sudo apt install git
sudo apt install wget
sudo apt install python
sudo apt install python2
pip2 install requests
pip2 install mechanize
wget https://raw.githubusercontent.com/ShuBhamg0sain/adb-termux/main/install.sh && bash install.sh
git clone https://github.com/ShuBhamg0sain/GHOSTSPLOIT.git
cd GHOSTSPLOIT
python2 linux.py
```


## Installation [Android](https://wikipedia.org/wiki/Android) [![alt tag](https://cdn1.iconfinder.com/data/icons/logotypes/32/android-32.png)](https://fr.wikipedia.org/wiki/Android)

Download [Termux](https://play.google.com/store/apps/details?id=com.termux)

```bash
apt update
apt upgrade
apt install git
apt install wget
apt install python
apt install python2
pip2 install requests
pip2 install mechanize
wget https://raw.githubusercontent.com/ShuBhamg0sain/adb-termux/main/install.sh && bash install.sh
git clone https://github.com/ShuBhamg0sain/GHOSTSPLOIT.git
cd GHOSTSPLOIT
python2 termux.py
```
