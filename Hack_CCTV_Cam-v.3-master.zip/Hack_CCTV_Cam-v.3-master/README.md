# Hack_CCTV_Cam-v.3



### screenshot
![ ](https://raw.githubusercontent.com/ShuBhamg0sain/Hack_CCTV_Cam-v.3/master/Screenshot_20200928_081406.jpg)

FIND...ME.

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈



## installation

apt-get install python3

apt-get install git

git clone https://github.com/ShuBhamg0sain/Hack_CCTV_Cam-v.3

pip3 install requests

cd Hack_CCTV_Cam-v.3

python3 cam-hackers.py
