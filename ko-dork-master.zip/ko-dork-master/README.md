# ko-dork
A simple vuln web scanner

```
$ pkg update upgrade
$ pkg install git python2
$ git clone https://github.com/ciku370/ko-dork
$ cd ko-dork
$ python2 dork.py
```

