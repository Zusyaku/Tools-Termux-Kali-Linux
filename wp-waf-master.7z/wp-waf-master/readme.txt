=== WP WAF ===
Contributors: guelfoweb
Donate link: http://www.guelfoweb.com/
Tags: security, firewall, waf
Requires at least: 3.3
Tested up to: 3.4
Stable tag: 2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WordPress Application Firewall. Protects against current and future attacks.

== Description ==

WordPress Application Firewall. Protects against current attacks. Email notification is disabled by default, notification can be activated and configured in <strong>Settings &gt; WP WAF</strong>. Go to your WP WAF configuration page.

== Screenshots ==

1. The Settings Page
2. The WAF Logo page

== Installation ==

You can download and install WP WAF using the built in WordPress plugin installer.

== Frequently Asked Questions ==

= Does this plugin protect against XSS e SQL Injection attacks? =

Yes, it does.

== Upgrade Notice ==

= 1.0 =
Add security by .htaccess

== Changelog ==

= 2.0 =
* Second release.

= 1.0 =
* First release.

