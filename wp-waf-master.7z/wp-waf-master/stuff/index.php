<html>
<head>
<title>WP_WAF</title>
</head>
<body>
	<center>
	<img src="wp_waf.png" />
	<br>
	See <a href="README">README</a> file for more info.
	</center>
</body>
</html>
