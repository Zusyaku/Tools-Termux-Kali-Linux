<img src="https://github.com/guelfoweb/wp-waf/blob/master/stuff/wp_waf.png?raw=true" alt="WordPress Web Application Firewall" title="WordPress Web Application Firewall" />

#### DOWNLOAD

<a href="https://github.com/guelfoweb/wp-waf/archive/master.zip">Click here</a> to download latest version (v.2.0β).

##### SETTINGS

<img src="https://raw.github.com/guelfoweb/wp-waf/master/screenshot-1.png" />

##### INFO
WP WAF is a WordPress Web Application Firewall.<br>
It is currently maintained by Gianni 'guelfoweb' Amato, who can be contacted at guelfoweb@gmail.com.<br>
Suggestions and criticism are welcome.

##### LICENSE
[GNU GPL 2] (http://www.gnu.org/copyleft/gpl.html)

##### SPONSOR
WP WAF is sponsored by [Security Side] (http://www.securityside.it).
