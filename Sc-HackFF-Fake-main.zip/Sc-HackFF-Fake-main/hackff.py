#SCRIPT HACK AKUN FF FAKE
#!/bin/python

#module
import os,sys,time
#clear
def hapus():
       os.system('clear')

#tampilan
def menu():
     hapus()
     os.system('figlet Hack akun FF') 
     print ('{•}============================={•}')
     print ('{√}Author    : Mr. SadClown     {√}')
     print ('{√}Team      : WHITE CYBER UNION{√}')
     print ('{•}============================={•}')
     id = input ('Masukan ID Target :')
     time.sleep(1)
     print('Sabar Tod Lagi Proses Pembobolan')
     time.sleep(5)
     print('      ')
     pas = input('Masukan Pasword baru yg mudah di ingat : ')
     time.sleep(3)
     print('      ')
     print('================================')
     print(' Sucses Tod √√√√')
     print('    ')
     print(' ID Target : ' +  id) 
     print(' Pasword. : ' + pas)

menu()
