## TRACK-IP
```
> pkg install nano

> pkg install git

> pkg install python

> pkg install python3

> git clone https://github.com/Aldi098/TRACK-IP

> cd TRACK-IP

> python3 ip-Generator-enc.py
```
## fungsi
```
> Lacak lokasi menggunakan IP
> Pasti tepat lokasi
```
## THANK YOU
```
> Allah SWT
> Bapak 
> Ibu
> Kaka
> Teman²
```
