# OPEN SOURCE
```
- Open Source nih buat belajar hehe

```

# install
```php

$ pkg install git

$ pkg install nano

$ pkg install bash

$ pkg install figlet

$ git clone https://github.com/Aldi098/Html

$ cd Html

$ Bash HTML.sh

```
