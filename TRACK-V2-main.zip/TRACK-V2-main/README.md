## TRACK-V2
```
pkg install update

pkg install nano

pkg install curl

pkg install bash

pkg install wget

wget install lolcat

pkg install git

git clone https://github.com/Aldi098/TRACK-V2

cd TRACK-V2

bash TRACK-V2.sh
```
## Fungsi
```
> Lacak lokasi menggunakan IP target
> 60% Akurat
> Pemograman bash
```
## Thank you
```
> Allah SWT
> Bapak
> Ibu
> Kaka
> Teman²
```
