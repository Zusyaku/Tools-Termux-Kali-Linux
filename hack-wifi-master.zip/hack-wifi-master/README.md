# hack-wifi

# Note
Find me....for username and password
# Find me on 

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈
### installation


pkg update 

 pkg upgrade 

pkg install git 

pkg install python2 

pip2 install --upgrade pip

git clone https://github.com/ShuBhamg0sain/hack-wifi

cd hack-wifi

chmod +x wifi-hacker.sh

pip2 install requests 

pip2 install mechanize

python Shubham.py







