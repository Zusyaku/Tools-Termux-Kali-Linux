# ODOS
## Install
```php
$ pkg update && pkg upgrade
$ pkg install git
$ pkg install python
$ git clone https://github.com/Aldi098/ODOS
$ cd ODOS
$ python DDOS.py
```
## Function
- [x] Attack Website
- [x] Using IP
- [x] Using Port
- [x] Unlimited Quantity
