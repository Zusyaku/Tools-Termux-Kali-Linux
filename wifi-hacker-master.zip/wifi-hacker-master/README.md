Shell Script For Attacking Wireless Connections Using Built-In Kali Tools. Supports All Securities (WEP, WPS, WPA, WPA2)


![Image](http://i.imgur.com/AjQIOik.jpg)
<br/><br/>
![Image](http://i.imgur.com/VK4Jd4v.jpg)
<br/><br/>
![Image](http://i.imgur.com/92EReev.jpg)
<br/><br/>
![Image](http://i.imgur.com/U7GG5qz.jpg)
<br/><br/>
![WEP](http://i.imgur.com/LF1g15f.jpg)
<br/><br/>
![Image](http://i.imgur.com/80ImpOo.jpg)
<br/><br/>
![Image](http://i.imgur.com/aBQVYqe.jpg)
<br/><br/>
![Image](http://i.imgur.com/8IA7NSg.jpg)
<br/><br/>
![Image](http://i.imgur.com/ItblUIv.jpg)
<br/><br/>
![Image](http://i.imgur.com/msIXnMB.jpg)
<br/><br/>
![Image](http://i.imgur.com/KEwNXH6.jpg)
<br/><br/>
![Image](http://i.imgur.com/WOKuzWc.jpg)
<br/><br/>
![Image](http://i.imgur.com/O8V5zLn.jpg)
<br/><br/>
![Image](http://i.imgur.com/I1XYuIu.jpg)
<br/><br/>
![EXTRAS](http://i.imgur.com/mqJpIAI.jpg)
<br/><br/>
