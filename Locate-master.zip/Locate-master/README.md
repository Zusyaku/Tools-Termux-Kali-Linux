# Locate


![Screenshot_20200911_201037](https://github.com/shubhamggosai/Locate/blob/master/Screenshot_20200911_201037.jpg)

# Find me on 

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈

 ### installation

pkg update 

pkg upgrade 

pkg install git 

pkg install python2 

pip2 install PHP

pkg install wget

git clone https://github.com/ShuBhamg0sain/Locate

cd Locate

pip2 install requests 

pip2 install mechanize
 
bash Shubham.sh


