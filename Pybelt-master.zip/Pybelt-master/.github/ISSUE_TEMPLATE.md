# Issue/idea please be specific:
<!--- Place your issue here ---> 

# Do you have an idea of how to fix this?
<!--- If no leave this blank or put 'n/a' --->

# How can this be reproduced?
<!--- Need exact steps on how to reproduce this issue please --->

# What are the running details of your environment? 
 - Installation method?
 <!--- git clone, download zip/tar, etc.. --->
 
 - Operating system and architecture?
 <!--- IG MS Windows 64bit --->
 
 - Program version:
 <!--- python pybelt.py --version --->
 
 - Full traceback exception:
 <!--- Pictures would be awesome, anything relevant will work --->

# A random fact about yourself
<!--- If you don't put this I won't respond ;) --->

