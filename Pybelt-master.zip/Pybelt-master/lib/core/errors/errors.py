class GoogleBlockException(Exception):
    pass
