from hash_cracker import HashCracker
