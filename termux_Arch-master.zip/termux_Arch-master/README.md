# termux_Arch

# Find me on 

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈


![ ](https://github.com/ShuBhamg0sain/termux_Arch/blob/master/IMG_20200916_180611.jpg)
# For latest version  of Arch 
 apt update

 apt upgrade

 git clone https://GitHub.com/ShuBhamg0sain/termux_Arch

 cd termux_Arch

 ls

 bash Arch.sh


# for artificial version of Arch

 pkg update -y && pkg install curl proot tar -y && curl https://raw.githubusercontent.com/AndronixApp/AndronixOrigin/master/Installer/Arch/armhf/arch.sh | bash
