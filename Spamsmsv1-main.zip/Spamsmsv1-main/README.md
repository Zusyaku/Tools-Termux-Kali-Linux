# Spamsmsv1

~pkg update && pkg upgrade

~pkg install python

~pkg install figlet

~pkg install git

~git clone https://github.com/MrSadClown/Spamsmsv1

~cd Spamsmsv1

~ls

~python main.py
