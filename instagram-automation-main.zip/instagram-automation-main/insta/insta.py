import os
os.system('xdg-open https://www.instagram.com/shubhamg0sain/?hl=en')
