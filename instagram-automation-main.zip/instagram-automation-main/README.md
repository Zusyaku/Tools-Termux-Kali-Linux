# instagram-automation

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈

instagram-automation 
![ ](https://raw.githubusercontent.com/ShuBhamg0sain/instagram-automation/main/us/ps/IMG_20210430_181207.jpg)
 
# installation
git clone https://github.com/ShuBhamg0sain/instagram-automation.git

cd instagram-automation

chmod +x install.sh

./install.sh

# inspire by
https://github.com/mustafadalga/Instagram-Bot
https://github.com/timgrossmann/InstaPy
https://github.com/hobbydevs/InstabotJS
https://github.com/maciejcieslar/instagrambot.git

# Some sources code 
https://hackernoon.com/how-to-create-an-instagram-bot-with-node-js-a289185a7d6f
