# LITEDDOS
This Tool Is Supporting For DDOS Activities, The Way Is Typing Command :  $ python2 islddos.py &lt;ip> &lt;port> &lt;packet>   example:  $python2 islddos.py 104.27.190.77 8080 100  IP target: 104.27.190.77 port: 8080 packet:100  Made In indonesia Indonesia Security Lite
